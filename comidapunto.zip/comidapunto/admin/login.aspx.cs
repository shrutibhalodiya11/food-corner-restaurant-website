﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        con.Open();

    }
    protected void btninsert_Click(object sender, EventArgs e)
    {
                DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter("select * from login where username='" + txtuname.Text + "'and password='" + txtpass.Text + "'", con);
        da.Fill(dt);
        if (dt.Rows.Count == 1)
        {

            Session["uname"] = txtuname.Text;
              
                Response.Redirect("home.aspx");
           
        }
        else
        {
            Response.Write("<script>alert('your username or password is wrong'); window.location.href='loginmaster.aspx';</script>");
        }
    }

     protected void btncancle_Click(object sender, EventArgs e)
     {
         txtuname.Text = " ";
         txtpass.Text = " ";
     }
     protected void btn3_Click(object sender, EventArgs e)
     {
         Response.Redirect("registration.aspx");
     }
     protected void btncancle_Click1(object sender, EventArgs e)
     {
         txtuname.Text = " ";
         txtpass.Text = " ";
     }

    }
