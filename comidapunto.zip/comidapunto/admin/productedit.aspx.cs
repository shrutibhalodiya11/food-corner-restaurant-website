﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Windows.Forms;


public partial class admin_productedit : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd;
    static DataSet ds = new DataSet();
    SqlDataAdapter da;
    int res = 0;
    public void refdata()
    {
        string id = Request.QueryString["id"];
        if (id == null)
        {
            Response.Redirect("productmaster.aspx");
        }
        ds.Clear();
        da = new SqlDataAdapter("select * from product where id=" + id, con);
        da.Fill(ds);
    }
    public void showdata()
    {
        txtnm.Text = ds.Tables[0].Rows[0]["name"].ToString();
        txtcy.Text = ds.Tables[0].Rows[0]["category"].ToString();
        txtprice.Text = ds.Tables[0].Rows[0]["price"].ToString();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        con.Open();
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx");
        }

        if (!IsPostBack)
        {
            refdata();
            showdata();
        }
    }
    protected void btnedit_Click1(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {

        string id = Request.QueryString["id"];
        cmd = new SqlCommand("update product set name=@name,catregory=@catergory,price=@price,image=@image where id=" + id, con);
        cmd.Parameters.AddWithValue("@name", txtnm.Text);
        cmd.Parameters.AddWithValue("@category", txtcy.Text);
        cmd.Parameters.AddWithValue("@price", txtprice.Text);
        cmd.Parameters.AddWithValue("@image", FileUpload1.FileName);
        String path = Server.MapPath("~/admin/product/");
        FileUpload1.SaveAs(path + FileUpload1.FileName);
        res = cmd.ExecuteNonQuery();
        if (res == 0)
        {

            Response.Write("<script>alert('Record not update'); window.location.href='productmaster.aspx';</script>");
        }
        else
        {

            Response.Redirect("productmaster.aspx");
        }
        con.Close();
    }
        else
        {
            Response.Write("<script>alert('PLEASE SELECT FILE');</script>");
        }
    }
}