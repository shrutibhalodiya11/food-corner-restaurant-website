﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Windows.Forms;



public partial class logininsert : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    int res = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
               con.ConnectionString = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        con.Open();
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx");
        }

    }

    
    protected void btninsert_Click(object sender, EventArgs e)
    {
                SqlCommand cmd = new SqlCommand("insert into login values(@name,@pass)", con);
                cmd.Parameters.AddWithValue("@name", txtuname.Text);
        cmd.Parameters.AddWithValue("@pass", txtpass.Text);
        res = cmd.ExecuteNonQuery();
        if (res == 0)
        {
            Response.Write("<script>alert('Record not insert'); window.location.href='login.aspx';</script>");

        }
        else
        {
           
            Response.Redirect("loginmaster.aspx");
        }
        con.Close();

   }
}