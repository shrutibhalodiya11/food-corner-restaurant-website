﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;


public partial class client_registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    int res = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        con.Open();
    }
    protected void btnregistration_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Registration values(@firstname,@lastname,@emailadress,@password);", con);

        cmd.Parameters.AddWithValue("@firstname", txtnm.Text);
        cmd.Parameters.AddWithValue("@lastname", txtlnm.Text);
        cmd.Parameters.AddWithValue("@emailadress", txtad.Text);
        cmd.Parameters.AddWithValue("@password", txtpass.Text);
        res = cmd.ExecuteNonQuery();
        if (res == 0)
        {
            Response.Write("<script>alert('Not Registred'); window.location.href='registration.aspx';</script>");

        }
        else
        {

            Response.Write("<script>alert('Registration Done'); window.location.href='login.aspx';</script>");
        }
        con.Close();
    }
}