﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class client_addtocart : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
                con.ConnectionString = WebConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
        con.Open();
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx");
        }

        if (!IsPostBack)
        {
            int id = Convert.ToInt32(Request.QueryString["id"]);
            SqlDataAdapter da = new SqlDataAdapter("select * from product where id=" + id, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            txtname.Text = dt.Rows[0][1].ToString();
            txtprice.Text = dt.Rows[0][3].ToString();
            img.ImageUrl = "~/admin/product/"+dt.Rows[0][4].ToString();
        }
    }
    protected void txtquantity_TextChanged(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(txtprice.Text);
        int b = Convert.ToInt32(txtquantity.Text);
        int ans = a * b;
        txttotal.Text = ans.ToString();
    }

   protected void btnok_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("insert into cart values(@name,@price,@image,@quantity,@total,@username)",con);
        cmd.Parameters.AddWithValue("@name", txtname.Text);
        cmd.Parameters.AddWithValue("@price", txtprice.Text);
        cmd.Parameters.AddWithValue("@image", img.ImageUrl);
        cmd.Parameters.AddWithValue("@quantity", txtquantity.Text);
        cmd.Parameters.AddWithValue("@total", txttotal.Text);
        cmd.Parameters.AddWithValue("@username", Session["uname"].ToString());
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("viewcard.aspx");
    }

  }
